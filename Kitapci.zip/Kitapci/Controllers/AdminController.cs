﻿using Kitapci.Models.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Kitapci.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Kitaplar()
        {
            using (KitapContext context = new KitapContext())
            {
                var Kitaplar = context.Kitap.ToList();
                return View(Kitaplar);
            }
        }
        public ActionResult KitapEkle()
        {
            return View();
        }
        public ActionResult KitapDuzenle(int KitapID)
        {
            using (KitapContext context = new KitapContext())
            {
                var _KitapDuzenle = context.Kitap.Where(x => x.ID == KitapID).FirstOrDefault();
                return View(_KitapDuzenle);
            }
        }
        public ActionResult KitapSil(int KitapID)
        {
            try
            {
                using (KitapContext context = new KitapContext())
                {
                    context.Kitap.Remove(context.Kitap.First(d => d.ID ==KitapID));
                    context.SaveChanges();
                    return RedirectToAction("Kitaplar", "Admin");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Silerken hata oluştu", ex.InnerException);
            }
        }
        [HttpPost]
        public ActionResult KitapEkle(Kitap k, HttpPostedFileBase file)
        {
            try
            {
                using (KitapContext context = new KitapContext())
                {
                    Kitap _kitap = new Kitap();
                    if (file != null && file.ContentLength > 0)
                    {
                        MemoryStream memoryStream = file.InputStream as MemoryStream;
                        if (memoryStream == null)
                        {
                            memoryStream = new MemoryStream();
                            file.InputStream.CopyTo(memoryStream);
                        }
                        _kitap.KitapFoto = memoryStream.ToArray();
                    }
                    _kitap.KitapAd = k.KitapAd;                    
                    _kitap.KitapYazar = k.KitapYazar;
                    _kitap.KitapTarih = DateTime.Now;
                    context.Kitap.Add(_kitap);
                    context.SaveChanges();
                    return RedirectToAction("Kitaplar", "Admin");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Eklerken hata oluştu");
            }
        }
        [HttpPost]
        public ActionResult KitapDuzenle(Kitap k, HttpPostedFileBase file)
        {
            try
            {
                using (KitapContext context = new KitapContext())
                {
                    var _kitapDuzenle = context.Kitap.Where(x => x.ID == k.ID).FirstOrDefault();
                    if (file != null && file.ContentLength > 0)
                    {
                        MemoryStream memoryStream = file.InputStream as MemoryStream;
                        if (memoryStream == null)
                        {
                            memoryStream = new MemoryStream();
                            file.InputStream.CopyTo(memoryStream);
                        }
                        _kitapDuzenle.KitapFoto = memoryStream.ToArray();
                    }
                    _kitapDuzenle.KitapAd = k.KitapAd;                    
                    _kitapDuzenle.KitapYazar = k.KitapYazar;
                    _kitapDuzenle.KitapTarih = DateTime.Now;
                    context.SaveChanges();
                    return RedirectToAction("Kitaplar", "Admin");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Güncellerken hata oluştu " + ex.Message);
            }

        }
    }
}