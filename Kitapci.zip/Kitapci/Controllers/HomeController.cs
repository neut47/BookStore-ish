﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Kitapci.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "OKitapci olarak amacımız..";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "İletişim bilgilerimiz..";

            return View();
        }

        public ActionResult Kategoriler()
        {
            ViewBag.Message = " ";

            return View();
        }

        public ActionResult ChangeCulture(string lang, string returnUrl)
        {
            Session["Culture"] = new CultureInfo(lang);
            return Redirect(returnUrl);
        }
    }
}