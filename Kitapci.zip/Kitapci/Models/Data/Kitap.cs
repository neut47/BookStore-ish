﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Kitapci.Models.Data
{
    public class Kitap
    {
        [Key]
        public int ID { get; set; }
        public byte[] KitapFoto { get; set; }
        public string KitapAd { get; set; }
        public string KitapYazar { get; set; }
        public Nullable<System.DateTime> KitapTarih { get; set; }
    }
}