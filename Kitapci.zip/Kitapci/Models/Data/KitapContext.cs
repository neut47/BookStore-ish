﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Kitapci.Models.Data
{
    public class KitapContext : DbContext
    {
        public DbSet<Kitap> Kitap { get; set; }
    }
}